public enum LIVINGCONDITION {
    HEALTHY,
    SICK,
    DYING,
    DEAD
}
